import json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts.regression_center import GUARD
d=OUT/'ui-server-r3';d.mkdir(exist_ok=False);guard=d/'guard';guard.mkdir();(guard/'sitecustomize.py').write_text(GUARD,encoding='utf8')
env={k:v for k,v in os.environ.items() if not k.startswith(('AGENT_','TICKET_','DEEPSEEK_','DASHSCOPE_','LANGCHAIN_','LANGSMITH_','RAG_','RAILWAY_')) and not k.endswith(('_API_KEY','_TOKEN'))}
env.update(TICKET_AI_SCENARIO_ROOT=str(OUT/'ui-candidates-r3'),NO_PROXY='localhost,127.0.0.1,::1',no_proxy='localhost,127.0.0.1,::1',RAILWAY_SIM_CLOCK_MODE='demo',PYTHONPATH=str(guard)+os.pathsep+str(ROOT),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',TICKET_DISABLE_LOCAL_SECRETS='1',TICKET_WEB_OFFLINE_ONLY='1',LANGCHAIN_TRACING_V2='false',LANGSMITH_TRACING='false',AGENT_PROVIDER='mock',AGENT_ENGINE='legacy',RAILWAY_SIMULATION_ENABLED='1',RAILWAY_SIM_DB_PATH=str(d/'simulation.sqlite'),TICKET_REGRESSION_NETWORK_LOG=str(d/'network-blocks.jsonl'),AGENT_DB_PATH=str(d/'unused-legacy.sqlite'),AGENT_TRACE_DIR=str(d/'unused-legacy-traces'),TICKET_API_USAGE_DIR=str(d/'api-usage'))
cmd=[sys.executable,'-B','-m','streamlit','run',str(ROOT/'web/app.py'),'--server.address=127.0.0.1','--server.port=8754','--server.headless=true','--server.fileWatcherType=none','--browser.gatherUsageStats=false']
with (d/'app.log').open('x',encoding='utf8') as log:p=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
(d/'server.json').write_text(json.dumps(dict(pid=p.pid,command=cmd,url='http://127.0.0.1:8754',external_guard=True),indent=2),encoding='utf8')
print(json.dumps(dict(pid=p.pid,url='http://127.0.0.1:8754')))
