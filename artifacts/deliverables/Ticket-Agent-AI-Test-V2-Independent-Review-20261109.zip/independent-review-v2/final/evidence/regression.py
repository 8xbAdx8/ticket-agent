"""Immutable snapshot; all pre-V39 tests, separate from the new V39 suite."""
import sys,json,subprocess,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts.regression_center import prepare
d=OUT/(sys.argv[1] if len(sys.argv)>1 else 'old-regression-r1');d.mkdir(exist_ok=False)
checkout,env,receipt=prepare(ROOT,d)
for name in ('schema.sql','hardening.sql','migration_002.sql'):shutil.copy2(ROOT/'target/v39'/name,checkout/'target/v39'/name)
for rel in ['artifacts/runtime/railway-static-phase8-20261102-184912/static.sqlite','artifacts/runtime/v39-architecture-v1.2.2-20261103-121613/schema.sql']:
 dest=checkout/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/rel,dest)
runroot=checkout/'artifacts/runtime/v391-d9-lifecycle-v2-tests';runroot.mkdir(exist_ok=True)
env.update(RAILWAY_SIM_DB_PATH=str(runroot/'simulation.sqlite'))
env.update(NO_PROXY='localhost,127.0.0.1,::1',no_proxy='localhost,127.0.0.1,::1')
runner=checkout/'v39_old_regression_runner.py'
runner.write_text('''import sys,json,contextlib,pytest
from pathlib import Path
from datetime import datetime,timezone
out=Path(sys.argv[1]);out.mkdir(exist_ok=False);rows=[]
class Recorder:
 def pytest_runtest_logreport(self,report):
  if report.when=='call' or report.when in ('setup','teardown') and (report.failed or report.skipped):rows.append(dict(case_id=report.nodeid,stage=report.when,status=report.outcome,is_subtest=type(report).__name__.lower()=='subtestreport',duration_s=report.duration,assertion_evidence=str(report.longrepr) if report.longrepr else None))
start=datetime.now(timezone.utc).isoformat()
args=['tests','-q','-p','no:cacheprovider','--junitxml='+str(out/'junit.xml'),'--basetemp='+str(Path.cwd()/'artifacts/runtime/v310-ai-v2-tests')]
with (out/'pytest.log').open('x',encoding='utf8') as log:
 with contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):code=pytest.main(args,plugins=[Recorder()])
(out/'results.json').write_text(json.dumps(dict(command=args,exit_code=int(code),started=start,ended=datetime.now(timezone.utc).isoformat(),python=sys.version,real_api_requests=0,results=rows),ensure_ascii=False,indent=2),encoding='utf8')
raise SystemExit(int(code))
''',encoding='utf-8')
env.update(RAILWAY_SIMULATION_ENABLED='0',TICKET_TEST_MODE='1')
cmd=[sys.executable,'-B',str(runner),str(d/'results')]
with (d/'process.log').open('x',encoding='utf-8') as log:code=subprocess.call(cmd,cwd=checkout,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
(d/'execution.json').write_text(json.dumps(dict(command=cmd,receipt=receipt,returncode=code),indent=2),encoding='utf-8')
print(json.dumps(dict(exit_code=code,out=str(d))))
