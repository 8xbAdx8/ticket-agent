"""Freeze review evidence only; no production DB connection or API request."""
import difflib
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
from scripts.regression_center import source_files
from scripts.package_team_handoff import scan

OUT=Path(__file__).resolve().parent
REVIEW=ROOT/'docs/reviews/independent-review-v2'
FINAL=REVIEW/'final'
FINAL.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf8') as stream:json.dump(value,stream,ensure_ascii=False,indent=2)
def copy(source,dest):
    dest.parent.mkdir(parents=True,exist_ok=True)
    assert not dest.exists(),str(dest)
    shutil.copy2(source,dest)

opening=json.loads((OUT/'opening.json').read_text('utf8'))
differences=[]
for name,before in opening['protected'].items():
    p=ROOT/name
    after=sha(p) if p.is_file() else None
    if after!=before:differences.append(dict(path=name,before=before,after=after))
assert not differences,differences
write(FINAL/'protection-final.json',dict(checked=len(opening['protected']),differences=differences))
changed=[]
for name,before in opening['source'].items():
    p=ROOT/name;after=sha(p) if p.is_file() else None
    if after!=before:changed.append(dict(path=name,before=before,after=after))
assert {r['path'] for r in changed}=={'PROJECT_STATUS.md','target/scenario_generator.py','web/scenario_generator.py'},changed
write(FINAL/'source-differences.json',changed)
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT,encoding='utf8').strip()
write(FINAL/'git-state.json',dict(branch=git('branch','--show-current'),head=git('rev-parse','HEAD'),status=git('status','--short','--untracked-files=all'),staged=git('diff','--cached','--name-status')))
assert git('rev-parse','HEAD')==opening['head']
assert not git('diff','--cached','--name-status')
check=subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True,text=True)
assert check.returncode==0
(FINAL/'git-diff-check.txt').write_text(check.stdout+check.stderr,encoding='utf8')
(FINAL/'worktree-against-head.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=ROOT))
modified=['target/scenario_generator.py','target/scenario_v310.py','target/scenario_plans.py','target/scenario_quality.py','web/scenario_generator.py','tests/test_ai_scenario_v2.py']
patch=''
for rel in modified:
    patch+=''.join(difflib.unified_diff([], (ROOT/rel).read_text('utf8').splitlines(True),fromfile='/dev/null',tofile=rel))
(FINAL/'current-complete-source.patch').write_text(patch,'utf8')
write(FINAL/'patch-scope.json',dict(note='HEAD diff includes earlier uncommitted work. Current complete source patch includes existing untracked files; opening only has hashes, not before text. Not a pure task incremental patch.',files=modified))

selected={name:p for name,p in source_files(ROOT).items() if '/' not in name or name.startswith(('target/','web/','tests/','scripts/'))}
for name in ('schema.sql','hardening.sql','migration_002.sql'):selected['target/v39/'+name]=ROOT/'target/v39'/name
write(FINAL/'source-sha256.json',{n:sha(p) for n,p in sorted(selected.items())})
with zipfile.ZipFile(FINAL/'source-snapshot.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,p in sorted(selected.items()):archive.write(p,'ticket-agent/'+name)

for name in ['opening.json','opening-source-recovery.json','providers-before.json','final-code-binding.json','baseline-comparison-r4.json','unit-r7.log','unit-r7.xml','adapter-r4-final.json','mutations-r4.json','coverage-r4.json','model-comparison-r4.json','budget-snapshot.json','live-candidates.json','live-summary.json','live-summary-r2.json','live-summary-r3.json','live-summary-r4.json','proxy-diagnostic.json','system-proxy-diagnostic.json','regression.py','campaign_r4.py','start_ui_r3.py','browser_r3.js','browser-r3.log','live_experiment.py','live_experiment_r2.py','live_experiment_r3.py','live_experiment_r4.py','package_review.py']:
    copy(OUT/name,FINAL/'evidence'/name)
for folder in ['browser-r3','live','live-attempt2','live-attempt3','live-attempt4']:
    for p in (OUT/folder).rglob('*'):
        if p.is_file():copy(p,FINAL/'evidence'/p.relative_to(OUT))
for p in (OUT/'final-regression-r4/results').iterdir():
    if p.is_file():copy(p,FINAL/'evidence/final-regression-r4/results'/p.name)
copy(OUT/'final-regression-r4/execution.json',FINAL/'evidence/final-regression-r4/execution.json')
for name in ['unit.log','unit.xml','unit-final.log','unit-final.xml','unit-r2.log','unit-r2.xml','unit-r3.log','unit-r3.xml','unit-r4.log','unit-r4.xml','unit-r5.log','unit-r5.xml','unit-r6.log','unit-r6.xml']:
    if (OUT/name).is_file():copy(OUT/name,FINAL/'evidence/prior-batches'/name)
for folder in ['final-regression','final-regression-r2','final-regression-r3']:
    for p in (OUT/folder/'results').iterdir():
        if p.is_file():copy(p,FINAL/'evidence/prior-batches'/folder/p.name)
for name in ['Ticket-Agent-AI-Test-Scenario-Generator-V2-Report.md']:
    copy(ROOT/'docs/reviews'/name,FINAL/name)
copy(ROOT/'PROJECT_STATUS.md',FINAL/'PROJECT_STATUS.md')

results=json.loads((OUT/'adapter-r4-final.json').read_text('utf8'))+json.loads((OUT/'mutations-r4.json').read_text('utf8'))
for result in results:
    root=Path(result['evidence_root']).resolve()
    assert root.is_relative_to((ROOT/'artifacts/runtime/v310-ai-executions').resolve())
    for p in root.rglob('*'):
        if p.is_file() and p.suffix.lower() not in ('.pyc',):copy(p,FINAL/'executions'/root.name/p.relative_to(root))
write(FINAL/'external-data-references.json',dict(note='Review evidence bundle, not a portable runtime. Existing static SQLite, original GTFS, frozen data and regression fixture ZIP remain in project; see original paths/SHA in opening protected manifest.',static_db='artifacts/runtime/railway-static-phase8-20261102-184912/static.sqlite',static_sha256=sha(ROOT/'artifacts/runtime/railway-static-phase8-20261102-184912/static.sqlite'),required_regression_package='artifacts/deliverables/Ticket-Agent-V3.6-P0-离线复测包-20261029-v2.zip',regression_package_sha256=sha(ROOT/'artifacts/deliverables/Ticket-Agent-V3.6-P0-离线复测包-20261029-v2.zip')))

payload={p.relative_to(REVIEW).as_posix():p.read_bytes() for p in REVIEW.rglob('*') if p.is_file()}
write(FINAL/'secret-scan.json',scan(payload))
write(REVIEW/'final-file-sha256.json',{p.relative_to(REVIEW).as_posix():sha(p) for p in sorted(REVIEW.rglob('*')) if p.is_file()})
archive=ROOT/'artifacts/deliverables/Ticket-Agent-AI-Test-V2-Independent-Review-20261109.zip'
archive.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as package:
    for p in REVIEW.rglob('*'):
        if p.is_file():package.write(p,'independent-review-v2/'+p.relative_to(REVIEW).as_posix())
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    manifest=json.loads(package.read('independent-review-v2/final-file-sha256.json'))
    for name,value in manifest.items():assert hashlib.sha256(package.read('independent-review-v2/'+name)).hexdigest()==value
write(OUT/'delivery.json',dict(archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),archive_integrity='PASS',manifest_entries=len(manifest),protected_checked=len(opening['protected']),protected_differences=0,overall='PARTIAL',independent_review='CONDITIONAL PASS'))
print((OUT/'delivery.json').read_text('utf8'))
