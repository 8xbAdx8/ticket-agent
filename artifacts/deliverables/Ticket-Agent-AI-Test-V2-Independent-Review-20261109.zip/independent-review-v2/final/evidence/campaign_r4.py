import sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from target.scenario_v310 import V310Adapter
from target.scenario_plans import plans
from target.scenario_quality import coverage,model_comparison
from target.scenario_generator import Store
OUT=Path(__file__).resolve().parent;results=[];faults=[]
for plan in plans():
 result=V310Adapter().run(plan);results.append(result);print(plan['title'],result['status'],flush=True)
for fault,title in [('wrong_arguments','lifecycle'),('missing_confirmation','lifecycle'),('fake_payment_success','lifecycle'),('missing_expiry','hold_expiry'),('ui_drift','railway_queries')]:
 result=V310Adapter().run(next(p for p in plans() if p['title']==title),fault=fault);faults.append(result);print('FAULT',fault,result['status'],flush=True)
(OUT/'adapter-r4-final.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8');(OUT/'mutations-r4.json').write_text(json.dumps(faults,ensure_ascii=False,indent=2),encoding='utf8')
report=coverage(results,faults);(OUT/'coverage-r4.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');store=Store(OUT/'live');comparison=model_comparison(store.original_candidates(),store.generations());(OUT/'model-comparison-r4.json').write_text(json.dumps(comparison,ensure_ascii=False,indent=2),encoding='utf8')
assert all(r['status']=='passed' for r in results)
assert all(r['status']=='failed' for r in faults)
print({k:v['display'] for k,v in report.items() if isinstance(v,dict) and 'display' in v},flush=True)
