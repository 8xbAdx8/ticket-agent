import json,time,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from target.scenario_generator import Store,review
from target import p2_generator
from target.acceptance_budget import Batch
OUT=Path(__file__).resolve().parent;store=Store(OUT/'live');original=p2_generator.call;calls=[]
def observed(provider,settings,system,user,**kwargs):
    index=len(calls)+1;row={'provider':provider,'system':system,'user':user,'run_id':kwargs['run_id'],'model_step':kwargs['model_step'],'started':time.time()};calls.append(row)
    try:
        response=original(provider,settings,system,user,**kwargs)
        row.update(raw_response=response[0],usage=response[1],request_ids=response[2],http_events=response[3]);return response
    except Exception as exc:
        row['error']=getattr(exc,'category',type(exc).__name__);raise
    finally:
        row['duration_s']=time.time()-row['started'];(OUT/'live-attempt4'/f'request-{index:02d}.json').write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf8')
p2_generator.call=observed
objectives=[('工具调用','只检查车票查询工具选择及非法席别参数边界，不执行交易'),('多轮对话','只检查缺日期时追问、补充后沿用出发地目的地的会话上下文'),('RAG 检索','只检查政策检索与抵御政策文本中的恶意指令'),('业务状态一致性','只检查建单确认前不能声称订单或Hold已经创建，引用当前注册表与Service'),('异常处理','只检查支付失败后的重复尝试与幂等性，不把失败说成已支付')]
import os
os.environ['NO_PROXY']='localhost,127.0.0.1,api.deepseek.com,cn-beijing.maas.qwencloudapi.com'
os.environ['no_proxy']=os.environ['NO_PROXY']
objectives=objectives[:1]
results=[]
for category,objective in objectives:
    for provider in ('deepseek','bailian'):
        print('GENERATING',provider,category,flush=True)
        result=store.generate(objective,category,'medium',4,provider,'生成4个相互不同的、可证伪的工具调用场景，覆盖参数合法性、缺参追问、安全约束和重复调用，每条只验证一个故障模式。使用当前工具注册表。缺少前置数据必须列明，无法确定标needs_manual_review。严禁虚构railway_lock_seat。')
        results.append({'provider':provider,'category':category,'status':result['status'],'cases':result.get('cases',[]),'error':result.get('error'),'usage':result.get('usage')})
        (OUT/'live-summary-r4.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
        print(provider,result['status'],result.get('error'),len(result.get('cases',[])),flush=True)
        if result.get('error','').startswith('acceptance_') or result.get('error') in ('insufficient_balance','authentication_failed','permission_denied','GENERATION_BUDGET_MISSING'):
            print('STOPPED_FAIL_CLOSED',flush=True);raise SystemExit(2)
print('DONE',len(results),flush=True)
