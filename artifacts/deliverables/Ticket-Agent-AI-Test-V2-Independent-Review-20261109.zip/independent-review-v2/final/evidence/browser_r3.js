const {chromium}=require('../v37-phase1-browser-20261101/tools/node_modules/playwright');
const fs=require('fs'),path=require('path');
const out=path.join(__dirname,'browser-r3');fs.mkdirSync(out);
const result={checks:[],pageErrors:[],consoleErrors:[],networkFailures:[]};
function save(){fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(result,null,2));}
function check(spec,name,ok){result.checks.push({spec,name,passed:!!ok});save();if(!ok)throw Error(name);}
(async()=>{const browser=await chromium.launch({channel:'msedge',headless:true});try{
for(const [width,height] of [[1600,900],[1366,768],[800,900],[390,844]])for(const dark of [false,true]){
 const spec=width+'-'+(dark?'dark':'light');const ctx=await browser.newContext({viewport:{width,height}});
 await ctx.route('**/*',r=>new URL(r.request().url()).hostname==='127.0.0.1'?r.continue():r.abort());
 const p=await ctx.newPage();p.on('pageerror',e=>result.pageErrors.push({spec,error:String(e)}));p.on('console',m=>{if(m.type()==='error')result.consoleErrors.push({spec,text:m.text()})});p.on('requestfailed',r=>result.networkFailures.push({spec,url:r.url()}));
 const settle=async()=>{await p.waitForTimeout(600);await p.locator('.stApp[data-test-script-state="notRunning"]').waitFor({timeout:60000});if(await p.locator('[data-testid="stException"]').count())throw Error(await p.locator('[data-testid="stException"]').innerText());};
 await p.goto('http://127.0.0.1:8754');await settle();
 const side=p.locator('[data-testid="stSidebar"]');let b=await side.boundingBox();if(!b||b.x<0)await p.locator('[data-testid="stExpandSidebarButton"]').click();
 await side.getByText('测试控制台',{exact:true}).click();await settle();await side.getByText('AI 测试场景生成',{exact:true}).click();await settle();await side.getByText(dark?'深色':'浅色',{exact:true}).click();await settle();
 if(width<600){await p.locator('[data-testid="stSidebarCollapseButton"] button').click();await settle();}
 check(spec,'module-navigation',await p.getByRole('heading',{name:'AI 测试场景生成',exact:true}).count());
 if(width===1600&&!dark){
  await p.getByText('V3.10 确定性集成计划',{exact:true}).click();await settle();await p.getByRole('button',{name:'载入参考计划为待审核候选',exact:true}).click();await settle();
  check(spec,'candidate-saved',(await p.locator('body').innerText()).includes('railway_queries'));
  if(!(await p.getByRole('button',{name:'独立执行已批准场景（V3.10确定性集成）',exact:true}).isEnabled())){const choices=p.getByRole('combobox',{name:'批量审核选择',exact:true});await choices.click();await choices.press('ArrowDown');await choices.press('Enter');await choices.press('Escape');await settle();await p.screenshot({path:path.join(out,'selection.png')});
  await p.getByLabel('审核人（写入审计记录）',{exact:true}).fill('UI验收');await p.getByLabel('审核人（写入审计记录）',{exact:true}).press('Tab');await settle();await p.getByRole('button',{name:'应用人工审核',exact:true}).click();await settle();
  }
  check(spec,'approved-enables-execution',await p.getByRole('button',{name:'独立执行已批准场景（V3.10确定性集成）',exact:true}).isEnabled());
  await p.getByRole('button',{name:'独立执行已批准场景（V3.10确定性集成）',exact:true}).click();await settle();
  check(spec,'execution-record',(await p.locator('body').innerText()).includes('passed'));
 }
 await p.reload();await settle();let box=await side.boundingBox();if(!box||box.x<0)await p.locator('[data-testid="stExpandSidebarButton"]').click();await side.getByText('测试控制台',{exact:true}).click();await settle();await side.getByText('AI 测试场景生成',{exact:true}).click();await settle();await side.getByText(dark?'深色':'浅色',{exact:true}).click();await settle();if(width<600){await p.locator('[data-testid="stSidebarCollapseButton"] button').click();await settle();}check(spec,'refresh-restores-case',(await p.locator('body').innerText()).includes('railway_queries'));
 check(spec,'no-horizontal-overflow',await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));
 check(spec,'generate-button-reachable',await p.getByRole('button',{name:'生成候选场景',exact:true}).isEnabled());
 await p.screenshot({path:path.join(out,spec+'.png'),fullPage:true});await p.getByRole('heading',{name:'候选场景管理',exact:true}).scrollIntoViewIfNeeded();await p.screenshot({path:path.join(out,spec+'-review.png')});let sb=await side.boundingBox();if(!sb||sb.x<0)await p.locator('[data-testid="stExpandSidebarButton"]').click();await side.getByText('测试总览',{exact:true}).click();await settle();check(spec,'original-overview',!(await p.locator('[data-testid="stException"]').count()));await side.getByText('用户工作空间',{exact:true}).click();await settle();check(spec,'original-user-composer',await p.getByRole('button',{name:'发送',exact:true}).count());await ctx.close();save();
}
}finally{await browser.close();save();}console.log(JSON.stringify({passed:result.checks.filter(c=>c.passed).length,failed:result.checks.filter(c=>!c.passed).length,pageErrors:result.pageErrors.length,consoleErrors:result.consoleErrors.length,networkFailures:result.networkFailures.length}));})().catch(e=>{result.error=String(e);save();console.error(e);process.exitCode=1;});
